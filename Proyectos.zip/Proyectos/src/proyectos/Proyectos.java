/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectos;

import java.util.Iterator;
import proyectos.ArraySet;
import proyectos.BusquedaOrdenamiento;
import java.util.Iterator;

/**
 *
 * @author luis_
 */
public class Proyectos {

    /**
     * @param the command line arguments
     */
    public static void main(String[] args) {

        // esto es bingo ball
//        
//     //   bingoBall a = new bingoBall(1);
//        bingoBall b = new bingoBall(20);
//        bingoBall c = new bingoBall(35);
//        bingoBall d = new bingoBall(35);
//        ArraySet<String> arreglo = new ArraySet<String>(5);
//        arreglo.add("juan");
//        arreglo.add("juan");
//        arreglo.add("coco");
//        arreglo.add("coco");
//
//        System.out.println(arreglo.size());
//        
//        Iterator t = arreglo.interator();
//        while (t.hasNext()){
//            System.out.println(t.next());
//        }
//        ArraySet<String> arreglo = new ArraySet<String>(4);
//        arreglo.add("corona");
//        arreglo.add("corona");
//        arreglo.add("victoria");
//
//        Integer[] a=new Integer[5];
//        a[0] = 4;
//        a[1] = 2;
//        a[2] = 7;
//        a[3] = 6;
//        a[4] = 9;
//        
//        BusquedaOrdenamiento<Integer>buscar=new BusquedaOrdenamiento<Integer>();
//        System.out.println(buscar.linearSearch(a, 0, 2, 6));
//         Persona p = new Persona();
//         Persona p1 = new Persona();
//         p.name = "alex";
//         p1.name = "david";
//         
//         p.next = p1;
//         p1.next = p;
//         
//         System.out.println();

    }
}
