/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas;

import pilas.*;
//import pilas.ArrayStack;
import java.util.Stack;
import pilas.ArrayStack;


/**
 *
 * @author luis_
 */
public class pilas {

    /**
     * 
     */
    public static void main(String[] args) {
         
        
 
//        ArrayStack pila =new ArrayStack();
// 
//        pila.push("elemento 1");
//        pila.push("elemento 2");
//        pila.push("elemento 3");
// 
//        System.out.println("1- push: "+ pila);
// 
//        pila.pop();
//        System.out.println("2- pop: "+ pila);
// 
//        String x  = (String) pila.peek();
//        System.out.println("3- peek: "+x);
// 
//        boolean y = pila.Empty;
//        System.out.println("4- empty: "+y);

          pilas p = new pilas(5);

    }
}
