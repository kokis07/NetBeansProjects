/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas;


/**
 *
 * @author luis_
 */
public class ArrayStack<T> implements StackADT<T>{
    
    private int count;
    private T[] contents;
    private final int DEFAULT_CAPACITY = 100;
    boolean Empty;
    
     public ArrayStack() {//constructor sin parametros.
        count = -1;//inicializa count en -1
        contents = (T[]) (new Object[DEFAULT_CAPACITY]);//crea el objeto con la capasidad por default.
    }
    //object clase generica todas las clases se heredan de object-

    public ArrayStack(int initialCapacity) {//el constructor con un parametro
        count = 0;//incializa count en 0
        contents = (T[]) (new Object[initialCapacity]);//inicia el objeto con la capacidad inicial(100).
    }
    
    public void push(T element) {
        count++;
        contents[count]=element;
    }

    
    public T pop() {
        T fuera = contents[count];
        count--;
        return fuera;
    }

    @Override
    public T peek() {
        return contents[count];
    }

    @Override
    public boolean isEmpty() {
        return count== -1;
    }

    @Override
    public int size() {
        return contents.length;
    }
    
}
